<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'mdetect',
    'version' => '4.10.5',
    'revision' => '$Revision: 7593 $',
    'path' => 'externals/mdetect',
    'repository' => 'socialengine.com',
    'title' => 'mDetect',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/mdetect',
    )
  )
) ?>