<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'swfobject',
    'version' => '4.10.5',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/swfobject',
    'repository' => 'socialengine.com',
    'title' => 'Swfobject',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/swfobject',
    )
  )
) ?>