<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'autocompleter',
    'version' => '4.10.5',
    'revision' => '$Revision: 10111 $',
    'path' => 'externals/autocompleter',
    'repository' => 'socialengine.com',
    'title' => 'Autocompleter',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/autocompleter',
    ),
  )
) ?>
