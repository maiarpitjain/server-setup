<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'calendar',
    'version' => '4.10.5',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/calendar',
    'repository' => 'socialengine.com',
    'title' => 'Calendar',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/calendar',
    )
  )
) ?>
