<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moocomet',
    'version' => '4.10.5',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/moocomet',
    'repository' => 'socialengine.com',
    'title' => 'Moocomet',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/moocomet',
    )
  )
) ?>