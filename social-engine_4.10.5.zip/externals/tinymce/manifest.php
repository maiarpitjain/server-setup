<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'tinymce',
    'version' => '4.10.5',
    'revision' => '$Revision: 10267 $',
    'path' => 'externals/tinymce',
    'repository' => 'socialengine.com',
    'title' => 'TinyMCE',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/tinymce',
    )
  )
) ?>
