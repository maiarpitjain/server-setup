<?php
/**
 * SocialEngine
 *
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: repositories.php 9747 2012-07-26 02:08:08Z john $
 */
defined('_ENGINE') or die('Access Denied'); return array(
  'socialengine.com' => array(
    'version' => '1.0',
    'host' => 'service.socialengine.net',
    'path' => '/',
  ),
) ?>